Thanks for purchasing Flowkit–Individual!

👍 You can use this for any personal or commercial project.

👎 This is an individual license for you alone. The file should not be shared with others.

🙏 Please honor the license and don't repackage or resell the file as your own. That would not be cool.

🖐 For help email matt@mds.is

Your pal,
MDS
